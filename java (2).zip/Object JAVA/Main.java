import java.util.*;
class Pen{
    String color;
    void display(){
        System.out.println(color+ " Pen is Writing");
    }
}
    public class Main{
        public static void main(String[] args){
            Pen myPen=new Pen();
            myPen.color="Blue";
            myPen.display();
        }
    }