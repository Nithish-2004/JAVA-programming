import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n = sc.nextInt();
	    int original, reverse= 0, digit;
	    
	    original = n;  
        while (n > 0) {  
        digit = n % 10;  
        reverse = reverse * 10 + digit;  
        n /= 10; 
        }
        if(original == reverse){
            System.out.println(original);
        }
        else{
            System.out.println(original);
        }
	    
	}
}
