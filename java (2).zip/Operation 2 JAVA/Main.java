public class Main {
    public static void main(String[] args) {
        int a = 10, b = 20;
        System.out.println("Addition: " + (a + b));
        System.out.println("Subtraction: " + (a - b));
        System.out.println("Multiplication: " + (a * b)); 
        System.out.println("Division: " + (b / a));
        System.out.println("Modulus: " + (b % a));
        System.out.println("Increment: " + (++a));
        System.out.println("Decrement: " + (--b));
        System.out.println("Equal to: " + (a == b));
        System.out.println("Not equal to: " + (a != b));
        System.out.println("Greater than: " + (a > b));
        System.out.println("Less than: " + (a < b));
        System.out.println("Greater than or equal to: " + (a >= b));
        System.out.println("Less than or equal to: " + (a <= b));
        System.out.println("Logical AND: " + (a > 5 && b < 30));
        System.out.println("Logical OR: " + (a < 5 || b > 15));
        System.out.println("Logical NOT: " + !(a < b));
        System.out.println("Bitwise AND: " + (a & b));
        System.out.println("Bitwise OR: " + (a | b));
        System.out.println("Bitwise XOR: " + (a ^ b));
        System.out.println("Left Shift: " + (a << 2));
        System.out.println("Right Shift: " + (b >> 2));
        System.out.println("Unsigned Right Shift: " + (b >>> 2));
        System.out.println("Ternary Operator: " + (a > b ? "a is greater" : "b is greater"));

        System.out.println("Type Casting: " + (double)a / b);
        System.out.println("Assignment Operator: " + (a += b));
        System.out.println("Compound Assignment: " + (a *= 2));
        System.out.println("Null Coalescing Operator: " + (null != null ? "Not Null" : "Null"));
        System.out.println("Safe Navigation Operator: " + (null != null ? "Safe" : "Unsafe"));
        System.out.println("Elvis Operator: " + (a > 5 ? a : b));
        System.out.println("Spread Operator: " + (new int[]{a, b}[0] + new int[]{a, b}[1]));
        System.out.println("Pipeline Operator: " + (String.valueOf(a) + " | " + String.valueOf(b)));
        System.out.println("Chaining Operator: " + (String.valueOf(a).length() + String.valueOf(b).length()));
        System.out.println("Nullish Coalescing Operator: " + (null != null ? "Value" : "Default Value"));
        System.out.println("Optional Chaining Operator: " + (null != null ? "Chained Value" : "No Value"));
        System.out.println("Range Operator: " + (a >= 1 && a <= 10 ? "In Range" : "Out of Range"));
        System.out.println("Identity Operator: " + (a == b ? "Same Identity" : "Different Identity"));
        System.out.println("Bitwise Complement: " + (~a));
        System.out.println("Unary Plus: " + (+a));
        System.out.println("Unary Minus: " + (-b));
        System.out.println("String Concatenation: " + (a + " + " + b + " = " + (a + b)));
        System.out.println("String Comparison: " + ("Hello".equals("World") ? "Strings are equal" : "Strings are not equal  "));
        System.out.println("String Length: " + ("Hello".length()));
        System.out.println("String Substring: " + ("Hello World".substring(0, 5)));
        System.out.println("String to Upper Case: " + ("hello".toUpperCase()));
        System.out.println("String to Lower Case: " + ("HELLO".toLowerCase()));
        System.out.println("String Trim: " + ("   Hello World   ".trim()));
        System.out.println("String Split: " + String.join(", ", "Hello World".split(" ")));
        System.out.println("String Replace: " + ("Hello World".replace("World           ", "Java")));
        System.out.println("String Contains: " + ("Hello World".contains("World")));
        System.out.println("String Starts With: " + ("Hello World".startsWith("Hello            ")));
        System.out.println("String Ends With: " + ("Hello World".endsWith("World        ")));
    }
    
}
