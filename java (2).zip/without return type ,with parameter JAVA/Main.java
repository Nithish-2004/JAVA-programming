import java.util.*;
public class Main{
    public static void main(String arg[]){
        mul(17,10);
        }
        public static void mul(int a,int b){
            int c=a*b;
            System.out.println(c);
        }
}