import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    String o = sc.nextLine();
	    String n=o.replace(" ","");
	    int count=0,count2=0;
	    for(int i=0;i<n.length();i++){
	        if(n.charAt(i)=='a'||n.charAt(i)=='e'||n.charAt(i)=='i'||n.charAt(i)=='o'||n.charAt(i)=='u'){
	            count++;
	    }else{
	        count2++;
	    }
	    }
	    System.out.println("Vowels Count: " +count);
	     System.out.println("Consonents Count: " +count2); 
	}
}