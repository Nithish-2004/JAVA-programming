import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n = sc.nextInt();
	    int reverse= 0,a=n;
        while (n != 0) {  
        int k = n % 10;  
        reverse = reverse * 10 + k;  
        n /= 10; 
        }
        if(a == reverse){
            System.out.println("Palindrome");
        }
        else{
            System.out.println("Not Palindrome");
        }
	    
	}
}
