public class Main { 
    public static void main(String[] args) {
        int a = 10, b = 20, c = 30;
        String result = (a > b) ? "a is greater" : (b > c) ? "b is greater" : "c is greatest";
        System.out.println("Nested Ternary Result: " + result);
    }
    
}
