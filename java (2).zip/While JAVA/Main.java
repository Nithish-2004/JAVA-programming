import java.util.*;
public class Main
{
	public static void main(String[] args) {
	   int count = 5;
	   while(count>0){
	       System.out.println("Count is: "+(count));
	       count--;
	   }
    }
}