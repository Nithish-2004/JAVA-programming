import java.util.*;
public class Main
{
	public static void main(String[] args) {
		int a = 10, b = 20;
		System.out.println("Addition: "+(a+b));
		System.out.println("Subraction: "+(a-b));
		System.out.println("Multiplication: "+(a*b));
		System.out.println("Division: "+(a/b));
		System.out.println("Modules: "+(a%b));
		System.out.println("Increment: "+(++a));
		System.out.println("Decrement: "+(--a));
		System.out.println("Equal to: "+(a==b));
		System.out.println("Greater than equal to: "+(a>=b));
		System.out.println("Less than equal to: "+(a<=b));
		System.out.println("Not equal to: "+(a!=b));
		System.out.println("Logical AND: "+(a>5 && b<21));
		System.out.println("Logical OR: "+(a>5 || b<10));
		System.out.println("Logical NOT: "+ !(a<b));
		System.out.println("Ternary Operator: " + (a > b ? "a is greater" : "b is greater"));
		System.out.println("Equal to: "+(a=b));
		System.out.println("Addition and Equal to: " + (a += b));
		System.out.println("Subraction and Equal to: " + (a -= b));
		System.out.println("Multiplication and Equal to: " + (a *= b));
		System.out.println("Division and Equal to: " + (a /= b));
		
	}
}
