import java.util.*;
public class Main{
    public static void main(String arg[]){
        System.out.println(mul());
        }
        public static int mul(){
            int a=13;
            int b=06;
            int c=a*b;
            return(c);
        }
       
}