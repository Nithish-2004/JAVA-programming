import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    String n = sc.nextLine();
	    StringBuffer sb=new StringBuffer(n);
	    String b=sb.reverse().toString();
	    if(b.equals(n)){
	        System.out.println("Palindrome : " +b);
	    }
	    else{
	        System.out.println("Not Palindrome : " +b);
	    } 
	    
	}
}
