import java.util.*;
public class Main{
    public static void main(String arg[]){
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int count=0;
        int temp=a;
        int hs=a;
        int b=0;
       while(a!=0){
            a/=10;
            count++;
        }
       while(temp!=0){
            int c=temp%10;
            b=b+(int)Math.pow(c,count);
            temp/=10;
       }
        if(hs==b){
            System.out.println("Armstrong number");
        }else{
            System.out.println("Not a Armstrong number");
        }
    }
}