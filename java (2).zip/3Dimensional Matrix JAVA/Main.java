import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n = sc.nextInt();
	    int m = sc.nextInt();
	    int o = sc.nextInt();
	    int ar[][][] = new int[n][m][o];
	    for(int i=0;i<n;i++){
	    for(int j=0;j<m;j++){
	    for(int k=0;k<o;k++){
	    ar[i][j][k]=sc.nextInt();
	    }   
	    }
	    }
	    for(int i=0;i<n;i++){
	    for(int j=0;j<m;j++){
	    for(int k=0;k<o;k++){
	    System.out.print(ar[i][j][k]+" ");   
	    }
	    System.out.println();
	    }
	    System.out.println();
	    }
	}
}
