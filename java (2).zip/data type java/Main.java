import java.util.*;
public class Main {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int age = sc.nextInt();
    float height = sc.nextFloat();
    String name = sc.next();
    double weight = sc.nextDouble();
    char gender = sc.next().charAt(0);
    boolean isStudent = sc.nextBoolean();
    long phoneNumber = sc.nextLong();
    short score = sc.nextShort();
    byte grade = sc.nextByte();
    System.out.println("Age: " + age);
    System.out.println("Height: " + height);
    System.out.println("Name: " + name);
    System.out.println("Weight: " + weight);
    System.out.println("Gender: " + gender);
    System.out.println("Is Student: " + isStudent);
    System.out.println("Phone Number: " + phoneNumber);
    System.out.println("Score: " + score);
    System.out.println("Grade: " + grade);
    }
}
