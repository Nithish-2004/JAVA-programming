import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int a=sc.nextInt();
	    if(a>=90 && a==100){
	        System.out.println("A Grade");
	    }
	    else if(a>=80 && a<=89){
	        System.out.println("B Grade");
	        }
	    else if(a>=70 && a<=79){
	        System.out.println("C Grade");
	    }
	    else{
	        System.out.println("Fail");
	    }
     }
	    
  }
