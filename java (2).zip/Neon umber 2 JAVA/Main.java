import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    int k=n*n;
	    int sum=0;
	    while(k!=0){
	        int a=k%10;
	        sum+=a;
	        k/=10;
	    }
	   if(sum==n){
	       System.out.println("Neon Number");   
	   }
	   else{
	       System.out.println("Not Neon Number");   
	   }
	}
}
