import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    String s1="Hi";
	    StringBuffer sbn=new StringBuffer(s1);
	    StringBuffer sb=new StringBuffer("Hello");
	        System.out.println(sbn.append("Hello"));
	        System.out.println(sbn.append("World"));
	        System.out.println(sb.insert(4,'o'));
	        System.out.println(sbn.delete(5,10));
	        System.out.println(sbn.replace(5,10,("lhood")));
	        System.out.println(sbn.reverse());
	}
}