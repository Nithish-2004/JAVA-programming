import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int a=sc.nextInt();
	    int ar[]=new int[a];
	    int sum=0;
	    for(int i=0;i<a;i++){
	     ar[i]=sc.nextInt();   
	    }
	    
	    for(int i=0;i<ar.length;i++){
	        sum+=ar[i];
	    }
	    System.out.println(sum);
	}
}