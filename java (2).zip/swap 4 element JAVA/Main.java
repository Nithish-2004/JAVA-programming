import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n = sc.nextInt();
	    int ar[] = new int[n];
	    for(int i=0;i<n;i++){
	        ar[i]=sc.nextInt();   // 1 2 3 4 5
	    }
	    for(int i=0;i<n-1;i+=2){
	        int temp=ar[i];
	        ar[i]=ar[i+1];
	        ar[i+1]=temp;
	    }
	    for(int i=0;i<n;i++){
	        System.out.print(ar[i]+" ");
	    }
	    }
	}

