import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    
	    Scanner sc=new Scanner(System.in);
	    String s=sc.nextLine();
	    String reverse="";
	    String words[]=s.split(" ");
	    for(int i=words.length -1;i>=0;i--){
	        reverse=reverse+words[i]+" ";
	    }
		System.out.println(reverse);
	}
}
