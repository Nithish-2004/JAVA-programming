import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    String s1=sc.nextLine();
	    String s2=sc.nextLine();
	        System.out.println(s1.charAt(0));
	        System.out.println(s1.length());
	        System.out.println(s1.substring(3));
	        System.out.println(s2.substring(3,7));
	        System.out.println(s1.contains("Hello"));
	        System.out.println(s2.contains("Hello World"));
	        System.out.println(String.join(" ",s1,s2));
	        System.out.println(s1.equals(s2));
	        System.out.println(s1.isEmpty());
	        System.out.println(s1.concat(s2));
	        System.out.println(s1.replace('l','v'));
	        System.out.println(s1.replaceAll("Hello", "World"));
	        System.out.println(s1.equalsIgnoreCase(s2));
	}
}