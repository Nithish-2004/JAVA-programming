import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String n=sc.nextLine();
	
		if(n.matches(".*\\d.*")){
		    System.out.println("True");
		}
		else{
		    System.out.print("False");
		}
	}
}