import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int a=sc.nextInt();
	    int c=a*a;
	   	System.out.println("Multiply Value: "+c);
	   	int d=c%2;
	   
	   	int e=c/10;
	   	
	   	int x=e+d;
	   	System.out.println("Neon Value: "+x);
	   	if(a==x){
	   	System.out.println("Neon Number");   
	   	}
	   	else{
	   	  System.out.println("Not Neon Number");     
	   	}
	}
}
