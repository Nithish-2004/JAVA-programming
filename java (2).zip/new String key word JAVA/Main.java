import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    
	    String s1=new String("Welcome");
	    String s2=new String("Welcome");
	        System.out.println(s1+" ");
	        System.out.println(s2+" ");
	    
	}
}