import java.util.*;
public class Main{
    public static void main(String arg[]){
        mul();
        }
        public static void mul(){
            int a=5;
            int b=2;
            int c=a*b;
            System.out.println(c);
        }
       
}