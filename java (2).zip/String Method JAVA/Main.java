import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s1 = sc.nextLine();
        String s2 = sc.nextLine(); 

        System.out.println(s1.charAt(0));
        System.out.println(s1.length());
        System.out.println(s1.substring(3));
        System.out.println(s2.substring(3, 7));
        System.out.println(s1.contains("Hello"));
        System.out.println(s2.contains("Hello World"));
        System.out.println(String.join(" ", s1, s2));
        System.out.println(s1.equals(s2));
        System.out.println(s1.isEmpty());
        System.out.println(s1.concat(s2));
        System.out.println(s1.replace('l', 'v'));
        System.out.println(s1.replaceAll("Hello", "World"));
        System.out.println(s1.equalsIgnoreCase(s2));
        String[] words = s1.split(" ");
        for (String word : words) {
            System.out.println("Split (no limit): " + word);
        }
        String[] wordsLimit = s1.split(" ", 2);
        for (String word : wordsLimit) {
            System.out.println("Split (limit 2): " + word);
        }
        System.out.println("Index of 'e' in s1: " + s1.indexOf('e'));
        System.out.println("Index of 'e' in s1 from index 2: " + s1.indexOf('e', 2));
        System.out.println("Index of \"lo\" in s1: " + s1.indexOf("lo"));
        System.out.println("Index of \"lo\" in s1 from index 2: " + s1.indexOf("lo", 2));
        System.out.println("s1 to lowercase: " + s1.toLowerCase());
        System.out.println("s1 to uppercase: " + s1.toUpperCase());
        String s3 = "   Hello World!   ";
        System.out.println("Trimmed: " + s3.trim());
        int num = 123;
        String numStr = String.valueOf(num);
        System.out.println("Value of int 123 as String: " + numStr);
    }
}
