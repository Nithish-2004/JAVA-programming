import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n = sc.nextInt();
	    int ar[]=new int[n];
	    for(int i = 0;i<n;i++){
	        ar[i]=sc.nextInt();
	    }
	    for(int i=0;i<n;i++){
	        for(int j=0;j<n;j++){
	            if(ar[i]<ar[j]){
	                int temp=ar[i];
	                ar[i]=ar[j];
	                ar[j]=temp;
	            }
	        }
	    }
	    for(int i=0;i<n;i++){
	        System.out.println(ar[i]+" ");
	    }
	}
}