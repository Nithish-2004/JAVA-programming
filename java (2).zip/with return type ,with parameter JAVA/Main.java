import java.util.*;
public class Main{
    public static void main(String arg[]){
        System.out.println(mul(17,5));
        }
        public static int mul(int a,int b){
            int c=a*b;
            return(c);
        }
       
}